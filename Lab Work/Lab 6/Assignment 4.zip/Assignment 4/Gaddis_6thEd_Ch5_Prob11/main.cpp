/* 
 * File:   main.cpp
 * Author: Johny Man Nguyen
 *
 * Created on July 14, 2015, 9:31 PM
 */

//Nguyen, Johny - Assignment 5 - 46091
//Gaddis_6thEd_Ch5_Prob11


#include <iostream>
using namespace std;

int main() {

int starting, avg_daily, no_days;

cout<<"Enter population of organism:"<<endl;
cin>>starting;

if (starting<2);

{
cout<<"Invalid Renter:";
cin>>starting;

}
if((avg_daily*starting)/(100));
cout<<"Enter number of days:";
cin>>no_days;
for (int i=0; i<no_days; i++)
{
starting = starting +avg_daily;
cout<<"Day"<<i+1<<":"<<starting<<endl;
}
	return 0;
}