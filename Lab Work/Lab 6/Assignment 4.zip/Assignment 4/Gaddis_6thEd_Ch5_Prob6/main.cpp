/* 
 * File:   main.cpp
 * Author: Johny Man Nguyen
 *
 * Created on July 14, 2015, 9:25 PM
 */
//Nguyen, Johny - Assignment 5 - 46091
//Gaddis_6thEd_Ch5_Prob6

#include <iostream>
using namespace std;

int main()
 {

float speed, time, distanceT = 0;

//Inputting Speed
cout<<"What is the speed of vehicle in mph?"<<endl;
cin>>speed;

//Input Time

cout<<"How many hours has it traveled?"<<endl;
cin>>time;

if (speed>=1)
{
if (time>1)
{
cout<<"Hour Distance Traveled\n";
cout<<"-------------"<<"\n";

for(int i=1; i=time; i++)
{
distanceT = speed * i;
cout<<i<<"  "<<distanceT<<endl;
}
}
else
cout<<"Time can't be less than 1"<<"\n";
}
else
cout<<"Speed can't be negative "<<"\n"<<endl;

	return 0;
}