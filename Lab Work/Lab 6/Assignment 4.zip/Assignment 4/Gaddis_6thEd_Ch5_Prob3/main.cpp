/* 
 * File:   main.cpp
 * Author: Johny Man Nguyen
 *
 * Created on July 14, 2015, 9:23 PM
 */
//Nguyen, Johny - Assignment 5 - 46091
//Gaddis_6thEd_Ch5_Prob3

#include <iostream>
using namespace std;

int main() {

//Declare Variables

int year;

double incLPY;
double totIL;

//Variable Initial

totIL = 0;
incLPY = 1.5;
year = 1;

//Display Header
cout<<"------------------------------"<<endl;
cout<<"Year\t\t\tTotal Increasing Level"<<endl;
cout<<"------------------------------"<<endl;

//Verify whether year is less than or equal to 25

while(year <=25)
{
//Calculate

totIL += incLPY;
cout<<year<<"\t\t\t"<<totIL<<"\tmillimeters"<<endl;
year++;
}
cout<<"------------------------------"<<endl;

	return 0;
}