/* 
 * File:   main.cpp
 * Author: Johny Man Nguyen
 *
 * Created on July 14, 2015, 9:20 PM
 */

//Nguyen, Johny - Assignment 5 - 46091
//Gaddis_6thEd_Ch5_Prob1
#include <iostream>

using namespace std;

int main() {

int num, sum=0;
cout<<"Enter a positive integer value:\n";
cin>> num;

for(int i=1; i<= num; i++) 
{
sum +=i;
}
cout<<"Sum of all the integers from 1 up to"<<num<<"is:"<<sum<<endl;
	
return 0;
}