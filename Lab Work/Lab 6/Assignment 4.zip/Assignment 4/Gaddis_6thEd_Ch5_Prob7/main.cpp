/* 
 * File:   main.cpp
 * Author: Johny Man Nguyen
 *
 * Created on July 14, 2015, 9:28 PM
 */

//Nguyen, Johny - Assignment 5 - 46091
//Gaddis_6thEd_Ch5_Prob7

#include <iostream>
#include <iomanip>
using namespace std;

int main() {

//Declare Variables

int totalD;

float pay, totalP=0;

{
cout<<"Enter number of days:";
cin>>totalD;
if(totalD<0 || totalD>31);

cout<<"Invalid Input: Number must be greater than zero"<<"less than or equal to 31"<<endl;


cout<<""<<endl;
cout<<"day\t$Salary"<<endl;
cout<<" "<<endl;
pay = 1;


cout<<fixed<<showpoint<<setprecision(2)<<endl;

for(int i=1; i<=totalD; i++)
}
{
cout<<i<<"\t$"<<pay<<endl;

totalP+=pay;

pay+=pay;

cout<<"Total pay for"<<totalD<<"days is $" <<totalP<<endl;

return 0;
}
}