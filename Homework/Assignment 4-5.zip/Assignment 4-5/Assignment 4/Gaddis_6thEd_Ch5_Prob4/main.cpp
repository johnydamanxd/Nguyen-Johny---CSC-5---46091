/* 
 * File:   main.cpp
 * Author: Johny Man Nguyen
 *
 * Created on July 14, 2015, 9:23 PM
 */

//Nguyen, Johny - Assignment 5 - 46091
//Gaddis_6thEd_Ch5_Prob4

#include <iostream>
using namespace std;

int main() {

//Variable Declaration 

float Total;
cout<<"Time (Mins) Calories Burned"<<endl;

//Start of Loop

for(int min=10; min<=30; min+=5)
{Total = (3.9)*min;

//Output Time and Calories Expended
cout<<min<<"\t\t\t"<<Total<<endl;
}
	return 0;
}