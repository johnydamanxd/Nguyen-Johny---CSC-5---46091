/* 
 * File:   main.cpp
 * Author: Johny Man Nguyen
 *
 * Created on July 14, 2015, 9:29 PM
 */

//Nguyen, Johny - Assignment 5 - 46091
//Gaddis_6thEd_Ch5_Prob12


#include <iostream>
using namespace std;

int main() {

float fahrenheit, Celsius;

cout<<"----------------"<<endl;
cout<<"Celsius\t"<<"fahrenheit"<<endl;
cout<"---------------";

for (int Celsius=0; Celsius<=20; Celsius++)
fahrenheit = (9/5)*Celsius+32;
cout<<Celsius<<"\t\t"<<fahrenheit<<endl;


	// your code goes here
	return 0;
}