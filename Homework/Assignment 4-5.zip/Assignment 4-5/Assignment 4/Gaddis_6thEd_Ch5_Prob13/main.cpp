/* 
 * File:   main.cpp
 * Author: Johny Man Nguyen
 *
 * Created on July 14, 2015, 9:30 PM
 */

//Nguyen, Johny - Assignment 5 - 46091
//Gaddis_6thEd_Ch5_Prob13


#include <iostream>
using namespace std;

int main() {

int number, large, small;

cout<<"Enter numbers in a series:"<<endl;
cin>>number;

large = small = number;

while(number!=-99);

{

if(number>large);
large=number;

if(number<small);
small=number;
cin>>number;
}

cout<<"Largest number is:"<<large<<endl;

cout<<"Smallest number is:"<<small<<endl;

	return 0;
}