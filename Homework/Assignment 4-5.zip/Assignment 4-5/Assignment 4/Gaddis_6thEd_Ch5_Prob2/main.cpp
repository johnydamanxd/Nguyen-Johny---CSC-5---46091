/* 
 * File:   main.cpp
 * Author: Johny Man Nguyen
 *
 * Created on July 14, 2015, 9:21 PM
 */

//Nguyen, Johny - Assignment 5 - 46091
//Gaddis_6thEd_Ch5_Prob2
#include <iostream>

using namespace std;

int main() {

for (int i=1; i<=127; i++)

{
if (i%16==0)
{
cout<<endl;
cout<<i<<static_cast<char>(i)<<"  ";
}
else
cout<<i<<static_cast<char>(i)<<"  ";
}
cout<<" \n";
	return 0;
}