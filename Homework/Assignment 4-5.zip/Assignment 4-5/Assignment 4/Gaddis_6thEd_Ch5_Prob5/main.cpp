/* 
 * File:   main.cpp
 * Author: Johny Man Nguyen
 *
 * Created on July 14, 2015, 9:24 PM
 */

//Nguyen, Johny - Assignment 5 - 46091
//Gaddis_6thEd_Ch5_Prob5

#include <iostream>
using namespace std;

int main() {

float charges = 2500.0;
cout<<"  "<<endl;
cout<<"Year\t Charges";
cout<<" "<<endl;
for(int i=1; i<=6; i++)
{
cout<<i<<"\t"<<charges;
charges+=charges*0.04;

}
	return 0;
}
